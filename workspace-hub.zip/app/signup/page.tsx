"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ThemeToggle } from "@/components/theme-toggle"
import { OrganizationForm } from "@/components/signup/organization-form"
import { UserForm } from "@/components/signup/user-form"
import { PreferencesForm } from "@/components/signup/preferences-form"
import { SuccessStep } from "@/components/signup/success-step"

// Define the stages of the signup process
type SignupStage = "organization" | "user" | "preferences" | "success"

// Define the data structure for the signup process
interface SignupData {
  organization: {
    name: string
    size: string
    industry: string
  }
  user: {
    name: string
    email: string
    password: string
  }
  preferences: {
    role: string
    department: string
    notifications: boolean
    termsAccepted: boolean
  }
}

export default function SignupPage() {
  // Track the current stage of the signup process
  const [currentStage, setCurrentStage] = useState<SignupStage>("organization")

  // Initialize the signup data
  const [signupData, setSignupData] = useState<SignupData>({
    organization: {
      name: "",
      size: "",
      industry: "",
    },
    user: {
      name: "",
      email: "",
      password: "",
    },
    preferences: {
      role: "",
      department: "",
      notifications: true,
      termsAccepted: false,
    },
  })

  // Calculate progress percentage based on current stage
  const getProgressPercentage = () => {
    switch (currentStage) {
      case "organization":
        return 25
      case "user":
        return 50
      case "preferences":
        return 75
      case "success":
        return 100
      default:
        return 0
    }
  }

  // Handle organization form submission
  const handleOrganizationSubmit = (orgData: SignupData["organization"]) => {
    setSignupData({ ...signupData, organization: orgData })
    setCurrentStage("user")
  }

  // Handle user form submission
  const handleUserSubmit = (userData: SignupData["user"]) => {
    setSignupData({ ...signupData, user: userData })
    setCurrentStage("preferences")
  }

  // Handle preferences form submission
  const handlePreferencesSubmit = (preferencesData: SignupData["preferences"]) => {
    setSignupData({ ...signupData, preferences: preferencesData })
    setCurrentStage("success")
  }

  // Handle going back to the previous stage
  const handleBack = () => {
    if (currentStage === "user") {
      setCurrentStage("organization")
    } else if (currentStage === "preferences") {
      setCurrentStage("user")
    }
  }

  // Render the current stage of the signup process
  const renderCurrentStage = () => {
    switch (currentStage) {
      case "organization":
        return <OrganizationForm initialData={signupData.organization} onSubmit={handleOrganizationSubmit} />
      case "user":
        return <UserForm initialData={signupData.user} onSubmit={handleUserSubmit} onBack={handleBack} />
      case "preferences":
        return (
          <PreferencesForm
            initialData={signupData.preferences}
            onSubmit={handlePreferencesSubmit}
            onBack={handleBack}
          />
        )
      case "success":
        return <SuccessStep data={signupData} />
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header with theme toggle */}
      <header className="flex items-center justify-between p-4 md:p-6">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl">
          <span className="bg-primary h-6 w-6 rounded-md"></span>
          WorkspaceHub
        </Link>
        <ThemeToggle />
      </header>

      <main className="flex-1 flex items-center justify-center p-4 md:p-8">
        <div className="w-full max-w-2xl">
          <Card>
            <CardContent className="pt-6">
              <div className="mb-8">
                <div className="flex justify-between mb-2 text-sm">
                  <span>Sign Up</span>
                  <span>
                    Step{" "}
                    {currentStage === "success"
                      ? 4
                      : currentStage === "preferences"
                        ? 3
                        : currentStage === "user"
                          ? 2
                          : 1}{" "}
                    of 4
                  </span>
                </div>
                <Progress value={getProgressPercentage()} className="h-2" />
              </div>

              {renderCurrentStage()}
            </CardContent>
          </Card>

          {currentStage !== "success" && (
            <div className="mt-4 text-center text-sm">
              Already have an account?{" "}
              <Link href="/login" className="text-primary hover:underline">
                Sign in
              </Link>
            </div>
          )}
        </div>
      </main>

      <footer className="py-6 text-center text-sm text-muted-foreground">
        <p>&copy; 2025 WorkspaceHub. All rights reserved.</p>
      </footer>
    </div>
  )
}
