"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Calendar, CheckSquare, FileText, Home, Menu, MessageSquare, PanelLeft, Settings, X } from "lucide-react"
import { useState, useEffect, useRef } from "react"
import { ThemeToggle } from "@/components/theme-toggle"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const [topNavOpen, setTopNavOpen] = useState(false)
  const pathname = usePathname()
  const touchStartX = useRef(0)
  const touchEndX = useRef(0)

  // Close mobile menu when window is resized to desktop size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) {
        setTopNavOpen(false)
      }
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  // Handle swipe for mobile
  useEffect(() => {
    const handleTouchStart = (e: TouchEvent) => {
      touchStartX.current = e.touches[0].clientX
    }

    const handleTouchMove = (e: TouchEvent) => {
      touchEndX.current = e.touches[0].clientX
    }

    const handleTouchEnd = () => {
      // Swipe right (to open sidebar)
      if (touchEndX.current - touchStartX.current > 100 && touchStartX.current < 50) {
        document.dispatchEvent(new CustomEvent("open-sidebar"))
      }

      // Swipe left (to close sidebar)
      if (touchStartX.current - touchEndX.current > 100) {
        document.dispatchEvent(new CustomEvent("close-sidebar"))
      }
    }

    document.addEventListener("touchstart", handleTouchStart)
    document.addEventListener("touchmove", handleTouchMove)
    document.addEventListener("touchend", handleTouchEnd)

    return () => {
      document.removeEventListener("touchstart", handleTouchStart)
      document.removeEventListener("touchmove", handleTouchMove)
      document.removeEventListener("touchend", handleTouchEnd)
    }
  }, [])

  // Check if a link is active
  const isActive = (path: string) => {
    return pathname === path || pathname.startsWith(`${path}/`)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 flex h-16 items-center border-b bg-background px-4 md:px-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setTopNavOpen(!topNavOpen)}>
            {topNavOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>

          <Link href="/dashboard" className="flex items-center gap-2 font-bold">
            <span className="bg-primary h-6 w-6 rounded-md"></span>
            WorkspaceHub
          </Link>

          <nav className="hidden md:flex gap-4">
            <Link href="/dashboard">
              <Button
                variant={
                  isActive("/dashboard") &&
                  !isActive("/dashboard/tasks") &&
                  !isActive("/dashboard/messages") &&
                  !isActive("/dashboard/documents") &&
                  !isActive("/dashboard/calendar")
                    ? "secondary"
                    : "ghost"
                }
                size="sm"
                className="gap-1"
              >
                <Home className="h-4 w-4" />
                Home
              </Button>
            </Link>
            <Link href="/dashboard/tasks">
              <Button variant={isActive("/dashboard/tasks") ? "secondary" : "ghost"} size="sm" className="gap-1">
                <CheckSquare className="h-4 w-4" />
                Tasks
              </Button>
            </Link>
            <Link href="/dashboard/messages">
              <Button variant={isActive("/dashboard/messages") ? "secondary" : "ghost"} size="sm" className="gap-1">
                <MessageSquare className="h-4 w-4" />
                Messages
              </Button>
            </Link>
            <Link href="/dashboard/documents">
              <Button variant={isActive("/dashboard/documents") ? "secondary" : "ghost"} size="sm" className="gap-1">
                <FileText className="h-4 w-4" />
                Documents
              </Button>
            </Link>
            <Link href="/dashboard/calendar">
              <Button variant={isActive("/dashboard/calendar") ? "secondary" : "ghost"} size="sm" className="gap-1">
                <Calendar className="h-4 w-4" />
                Calendar
              </Button>
            </Link>
          </nav>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 md:hidden"
            onClick={() => document.dispatchEvent(new CustomEvent("toggle-sidebar"))}
          >
            <PanelLeft className="h-4 w-4" />
          </Button>
          <ThemeToggle />
          <Button variant="ghost" size="icon">
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Mobile Top Navigation Menu */}
      {topNavOpen && (
        <div
          className="fixed inset-0 z-20 bg-background/80 backdrop-blur-sm md:hidden"
          onClick={() => setTopNavOpen(false)}
        >
          <div
            className="fixed top-16 left-0 z-20 w-full p-4 bg-background border-b"
            onClick={(e) => e.stopPropagation()}
          >
            <nav className="grid gap-2">
              <Link href="/dashboard" onClick={() => setTopNavOpen(false)}>
                <Button
                  variant={
                    isActive("/dashboard") &&
                    !isActive("/dashboard/tasks") &&
                    !isActive("/dashboard/messages") &&
                    !isActive("/dashboard/documents") &&
                    !isActive("/dashboard/calendar")
                      ? "secondary"
                      : "ghost"
                  }
                  size="sm"
                  className="w-full justify-start gap-2"
                >
                  <Home className="h-4 w-4" />
                  Home
                </Button>
              </Link>
              <Link href="/dashboard/tasks" onClick={() => setTopNavOpen(false)}>
                <Button
                  variant={isActive("/dashboard/tasks") ? "secondary" : "ghost"}
                  size="sm"
                  className="w-full justify-start gap-2"
                >
                  <CheckSquare className="h-4 w-4" />
                  Tasks
                </Button>
              </Link>
              <Link href="/dashboard/messages" onClick={() => setTopNavOpen(false)}>
                <Button
                  variant={isActive("/dashboard/messages") ? "secondary" : "ghost"}
                  size="sm"
                  className="w-full justify-start gap-2"
                >
                  <MessageSquare className="h-4 w-4" />
                  Messages
                </Button>
              </Link>
              <Link href="/dashboard/documents" onClick={() => setTopNavOpen(false)}>
                <Button
                  variant={isActive("/dashboard/documents") ? "secondary" : "ghost"}
                  size="sm"
                  className="w-full justify-start gap-2"
                >
                  <FileText className="h-4 w-4" />
                  Documents
                </Button>
              </Link>
              <Link href="/dashboard/calendar" onClick={() => setTopNavOpen(false)}>
                <Button
                  variant={isActive("/dashboard/calendar") ? "secondary" : "ghost"}
                  size="sm"
                  className="w-full justify-start gap-2"
                >
                  <Calendar className="h-4 w-4" />
                  Calendar
                </Button>
              </Link>
            </nav>
          </div>
        </div>
      )}

      {children}
    </div>
  )
}
