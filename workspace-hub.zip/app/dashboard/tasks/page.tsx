"use client"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  AlertCircle,
  ArrowUpDown,
  Calendar,
  CheckCircle2,
  Circle,
  Clock,
  Filter,
  Flag,
  MoreHorizontal,
  Plus,
  Search,
  Tag,
  User,
} from "lucide-react"
import { useSidebar } from "@/components/sidebar-toggle"
import { useState } from "react"

export default function TasksPage() {
  const { isOpen, toggleSidebar } = useSidebar()
  const [isNewIssueDialogOpen, setIsNewIssueDialogOpen] = useState(false)

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 md:hidden" onClick={toggleSidebar} />
      )}

      {/* Sidebar */}
      <div
        className={`
        fixed md:static inset-y-0 left-0 z-50 
        w-64 flex-col bg-gray-50 border-r dark:bg-gray-900
        transform transition-transform duration-200 ease-in-out
        ${isOpen ? "translate-x-0" : "-translate-x-full"} 
        md:translate-x-0 md:flex
      `}
      >
        <div className="flex h-14 items-center border-b px-4">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2 font-medium text-sm text-muted-foreground">Tasks</div>
          </div>
        </div>
        <div className="flex-1 overflow-auto py-2">
          <div className="px-3 py-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
              <Input type="search" placeholder="Search issues" className="w-full pl-8 text-sm" />
            </div>
          </div>
          <div className="mt-2">
            <div className="px-3 py-1.5">
              <span className="text-xs font-semibold text-gray-500 uppercase">Workspace</span>
            </div>
            <div className="mt-1">
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <CheckCircle2 className="h-4 w-4 mr-2" />
                My Issues
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium bg-gray-200 dark:bg-gray-800"
              >
                <Circle className="h-4 w-4 mr-2" />
                All Issues
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <User className="h-4 w-4 mr-2" />
                Assigned to Me
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <AlertCircle className="h-4 w-4 mr-2" />
                Backlog
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Calendar className="h-4 w-4 mr-2" />
                Roadmap
              </Button>
            </div>
          </div>
          <div className="mt-4">
            <div className="px-3 py-1.5 flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-500 uppercase">Projects</span>
              <Button variant="ghost" size="icon" className="h-5 w-5">
                <Plus className="h-3 w-3" />
              </Button>
            </div>
            <div className="mt-1">
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
                Website Redesign
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <div className="h-2 w-2 rounded-full bg-blue-500 mr-2"></div>
                Mobile App
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <div className="h-2 w-2 rounded-full bg-purple-500 mr-2"></div>
                API Integration
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <div className="h-2 w-2 rounded-full bg-yellow-500 mr-2"></div>
                Marketing Campaign
              </Button>
            </div>
          </div>
          <div className="mt-4">
            <div className="px-3 py-1.5 flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-500 uppercase">Labels</span>
              <Button variant="ghost" size="icon" className="h-5 w-5">
                <Plus className="h-3 w-3" />
              </Button>
            </div>
            <div className="mt-1">
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200 mr-2">
                  Bug
                </Badge>
                Bug
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200 mr-2">
                  Feature
                </Badge>
                Feature
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200 mr-2">
                  Enhancement
                </Badge>
                Enhancement
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200 mr-2">
                  Documentation
                </Badge>
                Documentation
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Header */}
        <header className="flex h-14 items-center justify-between border-b bg-white px-4 dark:bg-gray-950">
          <div className="flex items-center">
            <h1 className="text-xl font-semibold">Tasks</h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
              <Input type="search" placeholder="Search issues" className="w-64 pl-8 text-sm" />
            </div>
            <Button variant="outline" size="sm" className="gap-1">
              <Filter className="h-4 w-4" />
              Filter
            </Button>
            <Dialog open={isNewIssueDialogOpen} onOpenChange={setIsNewIssueDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="gap-1">
                  <Plus className="h-4 w-4" />
                  New Task
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[550px]">
                <DialogHeader>
                  <DialogTitle>Create New Task</DialogTitle>
                  <DialogDescription>Fill in the details to create a new task.</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="issue-title">Title</Label>
                    <Input id="issue-title" placeholder="Enter issue title" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="issue-description">Description</Label>
                    <Textarea id="issue-description" placeholder="Describe the issue in detail" rows={4} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="issue-type">Type</Label>
                      <Select>
                        <SelectTrigger id="issue-type">
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="bug">Bug</SelectItem>
                          <SelectItem value="feature">Feature</SelectItem>
                          <SelectItem value="enhancement">Enhancement</SelectItem>
                          <SelectItem value="documentation">Documentation</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="issue-priority">Priority</Label>
                      <Select>
                        <SelectTrigger id="issue-priority">
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="low">Low</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="issue-assignee">Assignee</Label>
                      <Select>
                        <SelectTrigger id="issue-assignee">
                          <SelectValue placeholder="Select assignee" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="john">John Doe</SelectItem>
                          <SelectItem value="sarah">Sarah Lee</SelectItem>
                          <SelectItem value="mike">Mike Thompson</SelectItem>
                          <SelectItem value="emily">Emily Chen</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="issue-status">Status</Label>
                      <Select defaultValue="backlog">
                        <SelectTrigger id="issue-status">
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="backlog">Backlog</SelectItem>
                          <SelectItem value="todo">To Do</SelectItem>
                          <SelectItem value="in-progress">In Progress</SelectItem>
                          <SelectItem value="done">Done</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsNewIssueDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={() => setIsNewIssueDialogOpen(false)}>Create Issue</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </header>

        {/* Main Content Area */}
        <div className="flex-1 overflow-auto p-4">
          <Tabs defaultValue="board">
            {/* Make the tablist in tasks more mobile-friendly */}
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <TabsList className="h-auto p-1">
                <TabsTrigger
                  value="board"
                  className="flex items-center gap-1 px-2 py-1 h-8 text-xs sm:text-sm sm:px-3 sm:py-1.5 sm:h-9 sm:gap-2"
                >
                  <CheckCircle2 className="h-3 w-3 sm:h-4 sm:w-4" />
                  <span>Board</span>
                </TabsTrigger>
                <TabsTrigger
                  value="list"
                  className="flex items-center gap-1 px-2 py-1 h-8 text-xs sm:text-sm sm:px-3 sm:py-1.5 sm:h-9 sm:gap-2"
                >
                  <ArrowUpDown className="h-3 w-3 sm:h-4 sm:w-4" />
                  <span>List</span>
                </TabsTrigger>
                <TabsTrigger
                  value="calendar"
                  className="flex items-center gap-1 px-2 py-1 h-8 text-xs sm:text-sm sm:px-3 sm:py-1.5 sm:h-9 sm:gap-2"
                >
                  <Calendar className="h-3 w-3 sm:h-4 sm:w-4" />
                  <span>Calendar</span>
                </TabsTrigger>
              </TabsList>
              <div className="flex items-center gap-2 flex-wrap">
                <Select defaultValue="all">
                  <SelectTrigger className="w-[120px] sm:w-[180px] h-8 text-xs">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="backlog">Backlog</SelectItem>
                    <SelectItem value="todo">To Do</SelectItem>
                    <SelectItem value="in-progress">In Progress</SelectItem>
                    <SelectItem value="review">In Review</SelectItem>
                    <SelectItem value="done">Done</SelectItem>
                  </SelectContent>
                </Select>
                <Select defaultValue="all">
                  <SelectTrigger className="w-[120px] sm:w-[180px] h-8 text-xs">
                    <SelectValue placeholder="Assignee" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Assignees</SelectItem>
                    <SelectItem value="me">Assigned to me</SelectItem>
                    <SelectItem value="unassigned">Unassigned</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Board View */}
            <TabsContent value="board" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {/* Backlog Column */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-2.5 w-2.5 rounded-full bg-gray-400"></div>
                      <h3 className="font-medium">Backlog</h3>
                      <span className="text-xs text-gray-500">4</span>
                    </div>
                    <Button variant="ghost" size="icon" className="h-7 w-7">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <ScrollArea className="h-[calc(100vh-220px)]">
                    <div className="space-y-3 pr-2">
                      <Card className="shadow-sm">
                        <CardContent className="p-3">
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">
                                Bug
                              </Badge>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" className="h-7 w-7">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>Edit</DropdownMenuItem>
                                  <DropdownMenuItem>Assign</DropdownMenuItem>
                                  <DropdownMenuItem>Add Label</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600">Delete</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                            <h4 className="font-medium">Fix login page validation errors</h4>
                            <p className="text-sm text-gray-500">
                              Users are experiencing validation errors when trying to log in with correct credentials.
                            </p>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1">
                                <Flag className="h-3 w-3 text-red-500" />
                                <span className="text-xs">High</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Tag className="h-3 w-3" />
                                <span className="text-xs">WEB-234</span>
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                <span className="text-xs">2d</span>
                              </div>
                              <Avatar className="h-6 w-6">
                                <AvatarImage src="/placeholder.svg?height=24&width=24" alt="Assignee" />
                                <AvatarFallback>AJ</AvatarFallback>
                              </Avatar>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* More cards would go here */}
                    </div>
                  </ScrollArea>
                </div>

                {/* Other columns would go here */}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
