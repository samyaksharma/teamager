"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  AtSign,
  Bell,
  ChevronDown,
  FileText,
  Hash,
  Lock,
  PaperclipIcon,
  Plus,
  Search,
  Send,
  Smile,
  Star,
  Users,
} from "lucide-react"
import { useSidebar } from "@/components/sidebar-toggle"

export default function MessagesPage() {
  const { isOpen, toggleSidebar } = useSidebar()

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 md:hidden" onClick={toggleSidebar} />
      )}

      {/* Channels Sidebar */}
      <div
        className={`
          fixed md:static inset-y-0 left-0 z-50 
          w-64 flex-col bg-gray-50 border-r dark:bg-gray-900
          transform transition-transform duration-200 ease-in-out
          ${isOpen ? "translate-x-0" : "-translate-x-full"} 
          md:translate-x-0 md:flex
        `}
      >
        <div className="flex h-14 items-center border-b px-4">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2 font-medium text-sm text-muted-foreground">Messages</div>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={toggleSidebar}>
              <ChevronDown className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="flex-1 overflow-auto py-2">
          <div className="px-3 py-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
              <Input type="search" placeholder="Search channels" className="w-full pl-8 text-sm" />
            </div>
          </div>
          <div className="mt-2">
            <div className="px-3 py-1.5 flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-500 uppercase">Channels</span>
              <Button variant="ghost" size="icon" className="h-5 w-5">
                <Plus className="h-3 w-3" />
              </Button>
            </div>
            <div className="mt-1">
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Hash className="h-4 w-4 mr-2" />
                general
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Hash className="h-4 w-4 mr-2" />
                random
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium bg-gray-200 dark:bg-gray-800"
              >
                <Hash className="h-4 w-4 mr-2" />
                product
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Hash className="h-4 w-4 mr-2" />
                engineering
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Hash className="h-4 w-4 mr-2" />
                marketing
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <Lock className="h-4 w-4 mr-2" />
                leadership
              </Button>
            </div>
          </div>
          <div className="mt-4">
            <div className="px-3 py-1.5 flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-500 uppercase">Direct Messages</span>
              <Button variant="ghost" size="icon" className="h-5 w-5">
                <Plus className="h-3 w-3" />
              </Button>
            </div>
            <div className="mt-1">
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <div className="relative mr-2">
                  <div className="h-4 w-4 rounded-full bg-green-500"></div>
                </div>
                Sarah Lee
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <div className="relative mr-2">
                  <div className="h-4 w-4 rounded-full bg-green-500"></div>
                </div>
                Mike Thompson
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <div className="relative mr-2">
                  <div className="h-4 w-4 rounded-full bg-gray-300"></div>
                </div>
                Alex Johnson
              </Button>
              <Button variant="ghost" className="w-full justify-start px-3 py-1.5 h-8 text-sm font-medium">
                <div className="relative mr-2">
                  <div className="h-4 w-4 rounded-full bg-gray-300"></div>
                </div>
                Emily Chen
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Channel Header */}
        <header className="flex h-14 items-center justify-between border-b bg-white px-4 dark:bg-gray-950">
          <div className="flex items-center">
            <div className="flex items-center">
              <Hash className="h-5 w-5 mr-2 text-gray-500" />
              <h1 className="font-semibold">product</h1>
            </div>
          </div>
          <div className="flex items-center gap-1 sm:gap-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Users className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Show members</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Star className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Star channel</TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <div className="relative hidden sm:block">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
              <Input type="search" placeholder="Search in channel" className="w-48 pl-8 text-sm" />
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Bell className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Notification preferences</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </header>

        {/* Messages Area */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-6">
            {/* Day Separator */}
            <div className="relative flex items-center py-2">
              <div className="flex-grow border-t"></div>
              <span className="mx-4 flex-shrink text-xs text-gray-500">Today</span>
              <div className="flex-grow border-t"></div>
            </div>

            {/* Message */}
            <div className="flex gap-3">
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Sarah" />
                <AvatarFallback>SL</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold">Sarah Lee</span>
                  <span className="text-xs text-gray-500">10:23 AM</span>
                </div>
                <div className="mt-1">
                  <p>
                    Hey team! I've updated the product roadmap for Q3. Take a look when you get a chance and let me know
                    your thoughts.
                  </p>
                  <div className="mt-2 flex items-center gap-2">
                    <Button variant="outline" size="sm" className="h-7 rounded-full px-3 text-xs">
                      👍 3
                    </Button>
                    <Button variant="outline" size="sm" className="h-7 rounded-full px-3 text-xs">
                      🎉 2
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 w-7 rounded-full p-0">
                      <Smile className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Message with Attachment */}
            <div className="flex gap-3">
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Mike" />
                <AvatarFallback>MT</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold">Mike Thompson</span>
                  <span className="text-xs text-gray-500">10:45 AM</span>
                </div>
                <div className="mt-1">
                  <p>I've also attached the latest design mockups for the new feature.</p>
                  <div className="mt-2">
                    <Card className="p-3 max-w-md">
                      <div className="flex items-center gap-2">
                        <FileText className="h-10 w-10 text-blue-500" />
                        <div>
                          <div className="font-medium">Product_Mockups_v2.pdf</div>
                          <div className="text-xs text-gray-500">4.2 MB • PDF</div>
                        </div>
                      </div>
                    </Card>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <Button variant="outline" size="sm" className="h-7 rounded-full px-3 text-xs">
                      👍 1
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 w-7 rounded-full p-0">
                      <Smile className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* More messages would go here */}
          </div>
        </ScrollArea>

        {/* Message Input */}
        <div className="border-t p-4">
          <div className="rounded-lg border bg-white dark:bg-gray-950">
            <div className="px-3 py-2">
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <PaperclipIcon className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <AtSign className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Smile className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <Separator />
            <div className="flex items-center p-3">
              <Input
                placeholder="Message #product"
                className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
              />
              <Button size="icon" className="ml-2 rounded-full">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
