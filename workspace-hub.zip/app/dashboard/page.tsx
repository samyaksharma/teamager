"use client"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Calendar,
  MessageSquare,
  FileText,
  CheckSquare,
  Clock,
  Plus,
  Search,
  Bell,
  Settings,
  Users,
  Hash,
} from "lucide-react"
import { useSidebar, SidebarToggle } from "@/components/sidebar-toggle"

export default function DashboardPage() {
  const { isOpen, toggleSidebar } = useSidebar()

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile Sidebar Toggle */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <SidebarToggle onToggle={toggleSidebar} isOpen={isOpen} />
      </div>

      {/* Mobile Sidebar Overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 md:hidden" onClick={toggleSidebar} />
      )}

      {/* Sidebar */}
      <div
        className={`
          fixed md:static inset-y-0 left-0 z-50 
          w-64 flex-col bg-gray-50 border-r dark:bg-gray-900
          transform transition-transform duration-200 ease-in-out
          ${isOpen ? "translate-x-0" : "-translate-x-full"} 
          md:translate-x-0 md:flex
        `}
      >
        <div className="flex h-14 items-center border-b px-4">
          <div className="flex items-center gap-2 font-bold">
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 h-5 w-5 rounded-md"></span>
            WorkspaceHub
          </div>
        </div>
        <div className="flex-1 overflow-auto py-2">
          <nav className="grid gap-1 px-2">
            <Button variant="ghost" className="justify-start gap-2">
              <CheckSquare className="h-4 w-4" />
              Tasks
            </Button>
            <Button variant="ghost" className="justify-start gap-2">
              <MessageSquare className="h-4 w-4" />
              Messages
            </Button>
            <Button variant="ghost" className="justify-start gap-2">
              <FileText className="h-4 w-4" />
              Documents
            </Button>
            <Button variant="ghost" className="justify-start gap-2">
              <Calendar className="h-4 w-4" />
              Calendar
            </Button>
            <Button variant="ghost" className="justify-start gap-2">
              <Users className="h-4 w-4" />
              Team
            </Button>
          </nav>
          <div className="mt-4 px-4 py-2">
            <h3 className="mb-2 text-xs font-semibold">Channels</h3>
            <div className="grid gap-1">
              <Button variant="ghost" size="sm" className="justify-start gap-2">
                <Hash className="h-4 w-4" />
                general
              </Button>
              <Button variant="ghost" size="sm" className="justify-start gap-2">
                <Hash className="h-4 w-4" />
                product
              </Button>
              <Button variant="ghost" size="sm" className="justify-start gap-2">
                <Hash className="h-4 w-4" />
                engineering
              </Button>
              <Button variant="ghost" size="sm" className="justify-start gap-2">
                <Hash className="h-4 w-4" />
                marketing
              </Button>
            </div>
          </div>
        </div>
        <div className="border-t p-4">
          <div className="flex items-center gap-3">
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-sm font-medium">John Doe</span>
              <span className="text-xs text-gray-500 dark:text-gray-400">john@example.com</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Header */}
        <header className="flex h-14 items-center gap-4 border-b bg-white px-4 dark:bg-gray-950">
          <div className="relative flex-1 md:max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
            <input
              type="search"
              placeholder="Search..."
              className="w-full rounded-md border border-gray-200 bg-white pl-8 text-sm ring-offset-white placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gray-950 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 dark:border-gray-800 dark:bg-gray-950 dark:ring-offset-gray-950 dark:placeholder:text-gray-400 dark:focus-visible:ring-gray-300"
            />
          </div>
          <Button variant="ghost" size="icon">
            <Bell className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon">
            <Settings className="h-4 w-4" />
          </Button>
          <Avatar className="h-8 w-8">
            <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
            <AvatarFallback>JD</AvatarFallback>
          </Avatar>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-auto p-4">
          <Tabs defaultValue="tasks">
            <div className="flex items-center justify-between mb-4">
              <TabsList>
                <TabsTrigger value="tasks" className="flex items-center gap-2">
                  <CheckSquare className="h-4 w-4" />
                  Tasks
                </TabsTrigger>
                <TabsTrigger value="messages" className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Messages
                </TabsTrigger>
                <TabsTrigger value="docs" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Documents
                </TabsTrigger>
              </TabsList>
              <Button size="sm" className="gap-1">
                <Plus className="h-4 w-4" />
                New
              </Button>
            </div>

            {/* Tasks Tab Content */}
            <TabsContent value="tasks" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>To Do</CardTitle>
                    <CardDescription>Tasks that need to be started</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="rounded-lg border p-3">
                        <div className="flex justify-between">
                          <h3 className="font-medium">Update homepage design</h3>
                          <Badge variant="outline">Design</Badge>
                        </div>
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                          Implement new hero section and features showcase
                        </p>
                        <div className="mt-2 flex items-center text-xs text-gray-500 dark:text-gray-400">
                          <Clock className="mr-1 h-3 w-3" />
                          Due in 3 days
                        </div>
                      </div>
                      <div className="rounded-lg border p-3">
                        <div className="flex justify-between">
                          <h3 className="font-medium">API integration</h3>
                          <Badge variant="outline">Dev</Badge>
                        </div>
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                          Connect payment gateway API to checkout flow
                        </p>
                        <div className="mt-2 flex items-center text-xs text-gray-500 dark:text-gray-400">
                          <Clock className="mr-1 h-3 w-3" />
                          Due in 5 days
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>In Progress</CardTitle>
                    <CardDescription>Tasks currently being worked on</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="rounded-lg border p-3">
                        <div className="flex justify-between">
                          <h3 className="font-medium">User authentication</h3>
                          <Badge variant="outline">Dev</Badge>
                        </div>
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                          Implement OAuth and email verification
                        </p>
                        <div className="mt-2 flex items-center text-xs text-gray-500 dark:text-gray-400">
                          <Clock className="mr-1 h-3 w-3" />
                          Due tomorrow
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Done</CardTitle>
                    <CardDescription>Completed tasks</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="rounded-lg border p-3">
                        <div className="flex justify-between">
                          <h3 className="font-medium line-through text-gray-500">Database setup</h3>
                          <Badge variant="outline">Dev</Badge>
                        </div>
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400 line-through">
                          Configure PostgreSQL and initial schema
                        </p>
                        <div className="mt-2 flex items-center text-xs text-gray-500 dark:text-gray-400">
                          <CheckSquare className="mr-1 h-3 w-3" />
                          Completed
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Messages Tab Content */}
            <TabsContent value="messages">
              <Card>
                <CardHeader>
                  <CardTitle>Team Chat</CardTitle>
                  <CardDescription>Communicate with your team in real-time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Sarah" />
                        <AvatarFallback>SL</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">Sarah Lee</span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">10:23 AM</span>
                        </div>
                        <p className="text-sm">
                          I've updated the design mockups for the landing page. Can everyone take a look and provide
                          feedback?
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Mike" />
                        <AvatarFallback>MT</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">Mike Thompson</span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">10:30 AM</span>
                        </div>
                        <p className="text-sm">
                          Looks great! I especially like the new hero section. The animation is smooth.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=40&width=40" alt="John" />
                        <AvatarFallback>JD</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">John Doe</span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">10:42 AM</span>
                        </div>
                        <p className="text-sm">
                          I agree with Mike. The new design looks much cleaner. I've added some comments in the
                          document.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Documents Tab Content */}
            <TabsContent value="docs">
              <Card>
                <CardHeader>
                  <CardTitle>Knowledge Base</CardTitle>
                  <CardDescription>Team documentation and resources</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      <div className="rounded-lg border p-4">
                        <FileText className="h-8 w-8 mb-2 text-purple-600" />
                        <h3 className="font-medium">Product Roadmap</h3>
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                          Our product vision and upcoming features
                        </p>
                        <div className="mt-3 flex items-center text-xs text-gray-500 dark:text-gray-400">
                          Updated 2 days ago
                        </div>
                      </div>
                      <div className="rounded-lg border p-4">
                        <FileText className="h-8 w-8 mb-2 text-pink-600" />
                        <h3 className="font-medium">Design System</h3>
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                          UI components and design guidelines
                        </p>
                        <div className="mt-3 flex items-center text-xs text-gray-500 dark:text-gray-400">
                          Updated 5 days ago
                        </div>
                      </div>
                      <div className="rounded-lg border p-4">
                        <FileText className="h-8 w-8 mb-2 text-blue-600" />
                        <h3 className="font-medium">API Documentation</h3>
                        <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                          Technical reference for our API endpoints
                        </p>
                        <div className="mt-3 flex items-center text-xs text-gray-500 dark:text-gray-400">
                          Updated 1 week ago
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}

function Menu(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="4" x2="20" y1="12" y2="12" />
      <line x1="4" x2="20" y1="6" y2="6" />
      <line x1="4" x2="20" y1="18" y2="18" />
    </svg>
  )
}
