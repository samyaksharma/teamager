"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChevronDown, ChevronRight, FileText, Folder, Plus, Search } from "lucide-react"
import { DocumentEditor } from "./document-editor"
import { useSidebar } from "@/components/sidebar-toggle"

export default function DocumentsPage() {
  const [activeDocument, setActiveDocument] = useState("Product Specs")
  const { isOpen, toggleSidebar } = useSidebar()

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {isOpen && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 md:hidden" onClick={toggleSidebar} />
      )}

      {/* Sidebar - Hidden on mobile unless toggled */}
      <div
        className={`
        fixed md:static inset-y-0 left-0 z-50 
        w-64 flex-col bg-background border-r 
        transform transition-transform duration-200 ease-in-out
        ${isOpen ? "translate-x-0" : "-translate-x-full"} 
        md:translate-x-0 md:flex
      `}
      >
        <div className="flex h-16 items-center border-b px-4">
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2 font-medium text-sm text-muted-foreground">Documents</div>
          </div>
        </div>
        <div className="flex-1 overflow-auto py-4">
          <div className="px-4 py-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search documents" className="w-full pl-8 text-sm" />
            </div>
          </div>
          <div className="mt-4">
            <div className="px-4 py-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Workspace</span>
              <Button variant="ghost" size="icon" className="h-6 w-6">
                <Plus className="h-3 w-3" />
              </Button>
            </div>
            <div className="mt-2 space-y-1">
              <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                <FileText className="h-4 w-4 mr-3" />
                Getting Started
              </Button>
              <div>
                <Button
                  variant="ghost"
                  className="w-full justify-start px-4 py-2 h-9 text-sm font-medium"
                  onClick={() => {
                    // Toggle the expanded state
                    const productSection = document.getElementById("product-section")
                    if (productSection) {
                      productSection.classList.toggle("hidden")
                    }
                  }}
                >
                  <ChevronDown className="h-4 w-4 mr-3" id="product-chevron" />
                  <Folder className="h-4 w-4 mr-3" />
                  Product
                </Button>
                <div className="pl-10 space-y-1" id="product-section">
                  <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                    <FileText className="h-4 w-4 mr-3" />
                    Roadmap
                  </Button>
                  <Button
                    variant="ghost"
                    className={`w-full justify-start px-4 py-2 h-9 text-sm font-medium ${activeDocument === "Product Specs" ? "bg-secondary" : ""}`}
                    onClick={() => setActiveDocument("Product Specs")}
                  >
                    <FileText className="h-4 w-4 mr-3" />
                    Product Specs
                  </Button>
                </div>
              </div>
              <div>
                <Button
                  variant="ghost"
                  className="w-full justify-start px-4 py-2 h-9 text-sm font-medium"
                  onClick={() => {
                    // Toggle the expanded state
                    const engineeringSection = document.getElementById("engineering-section")
                    if (engineeringSection) {
                      engineeringSection.classList.toggle("hidden")
                    }
                    // Toggle the chevron
                    const chevron = document.getElementById("engineering-chevron")
                    if (chevron) {
                      chevron.classList.toggle("rotate-90")
                    }
                  }}
                >
                  <ChevronRight className="h-4 w-4 mr-3 transition-transform" id="engineering-chevron" />
                  <Folder className="h-4 w-4 mr-3" />
                  Engineering
                </Button>
                <div className="pl-10 space-y-1 hidden" id="engineering-section">
                  <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                    <FileText className="h-4 w-4 mr-3" />
                    Architecture
                  </Button>
                  <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                    <FileText className="h-4 w-4 mr-3" />
                    API Docs
                  </Button>
                </div>
              </div>
              <div>
                <Button
                  variant="ghost"
                  className="w-full justify-start px-4 py-2 h-9 text-sm font-medium"
                  onClick={() => {
                    // Toggle the expanded state
                    const marketingSection = document.getElementById("marketing-section")
                    if (marketingSection) {
                      marketingSection.classList.toggle("hidden")
                    }
                    // Toggle the chevron
                    const chevron = document.getElementById("marketing-chevron")
                    if (chevron) {
                      chevron.classList.toggle("rotate-90")
                    }
                  }}
                >
                  <ChevronRight className="h-4 w-4 mr-3 transition-transform" id="marketing-chevron" />
                  <Folder className="h-4 w-4 mr-3" />
                  Marketing
                </Button>
                <div className="pl-10 space-y-1 hidden" id="marketing-section">
                  <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                    <FileText className="h-4 w-4 mr-3" />
                    Campaign Plan
                  </Button>
                  <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                    <FileText className="h-4 w-4 mr-3" />
                    Brand Guidelines
                  </Button>
                </div>
              </div>
              <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                <FileText className="h-4 w-4 mr-3" />
                Team Directory
              </Button>
              <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                <FileText className="h-4 w-4 mr-3" />
                Meeting Notes
              </Button>
            </div>
          </div>
          <div className="mt-6">
            <div className="px-4 py-2 flex items-center justify-between">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Recent</span>
            </div>
            <div className="mt-2 space-y-1">
              <Button
                variant="ghost"
                className="w-full justify-start px-4 py-2 h-9 text-sm font-medium"
                onClick={() => setActiveDocument("Product Specs")}
              >
                <FileText className="h-4 w-4 mr-3" />
                Product Specs
              </Button>
              <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                <FileText className="h-4 w-4 mr-3" />
                Weekly Update
              </Button>
              <Button variant="ghost" className="w-full justify-start px-4 py-2 h-9 text-sm font-medium">
                <FileText className="h-4 w-4 mr-3" />
                API Documentation
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        <DocumentEditor />
      </div>
    </div>
  )
}
