"use client"

import { useEffect, useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Bold,
  ChevronDown,
  Code,
  FileText,
  ImageIcon,
  Italic,
  Link,
  List,
  ListOrdered,
  Save,
  Share2,
  Star,
  Strikethrough,
  Table,
  Underline,
  Eye,
  PenLine,
  Presentation,
  History,
  MoreHorizontal,
  Clock,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  CheckSquare,
  Undo,
  Redo,
  FileIcon as FileTemplate,
  MessageSquare,
  Bookmark,
} from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { X } from "lucide-react"

type ViewMode = "edit" | "read" | "present"

export function DocumentEditor() {
  const [documentTitle, setDocumentTitle] = useState("Product Specifications")
  const [lastSaved, setLastSaved] = useState(new Date())
  const [isSaving, setIsSaving] = useState(false)
  const [viewMode, setViewMode] = useState<ViewMode>("edit")
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false)
  const [isVersionHistoryOpen, setIsVersionHistoryOpen] = useState(false)
  const [isCollaborationDialogOpen, setIsCollaborationDialogOpen] = useState(false)
  const [isCommentMode, setIsCommentMode] = useState(false)
  const editorRef = useRef<HTMLDivElement>(null)
  const [collaborators, setCollaborators] = useState([
    { id: 1, name: "John Doe", avatar: "/placeholder.svg?height=24&width=24", initials: "JD", online: true },
    { id: 2, name: "Sarah Lee", avatar: "/placeholder.svg?height=24&width=24", initials: "SL", online: true },
    { id: 3, name: "Mike Thompson", avatar: "/placeholder.svg?height=24&width=24", initials: "MT", online: false },
  ])

  // Auto-save functionality
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      saveDocument()
    }, 30000) // Auto-save every 30 seconds

    return () => clearInterval(autoSaveInterval)
  }, [])

  // Save document function
  const saveDocument = () => {
    setIsSaving(true)

    // Simulate saving to server
    setTimeout(() => {
      setLastSaved(new Date())
      setIsSaving(false)
    }, 800)
  }

  // Format the last saved time
  const formatLastSaved = (date) => {
    const now = new Date()
    const diffInMinutes = Math.floor((now - date) / (1000 * 60))

    if (diffInMinutes < 1) return "just now"
    if (diffInMinutes === 1) return "1 minute ago"
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`

    const diffInHours = Math.floor(diffInMinutes / 60)
    if (diffInHours === 1) return "1 hour ago"
    if (diffInHours < 24) return `${diffInHours} hours ago`

    return date.toLocaleDateString()
  }

  // Execute document commands
  const execCommand = (command, showUI = false, value = null) => {
    document.execCommand(command, showUI, value)
  }

  // Insert HTML at cursor position
  const insertHTML = (html) => {
    document.execCommand("insertHTML", false, html)
  }

  // Format block (paragraph, heading, etc.)
  const formatBlock = (blockType) => {
    document.execCommand("formatBlock", false, blockType)
  }

  // Insert link
  const insertLink = () => {
    const url = prompt("Enter link URL:")
    if (url) document.execCommand("createLink", false, url)
  }

  // Insert image
  const insertImage = () => {
    const url = prompt("Enter image URL:")
    if (url) document.execCommand("insertImage", false, url)
  }

  // Insert table
  const insertTable = () => {
    const table = `
      <table class="border-collapse w-full my-4">
        <thead>
          <tr class="bg-secondary">
            <th class="border p-3 text-left">Header 1</th>
            <th class="border p-3 text-left">Header 2</th>
            <th class="border p-3 text-left">Header 3</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="border p-3">Cell 1</td>
            <td class="border p-3">Cell 2</td>
            <td class="border p-3">Cell 3</td>
          </tr>
          <tr>
            <td class="border p-3">Cell 4</td>
            <td class="border p-3">Cell 5</td>
            <td class="border p-3">Cell 6</td>
          </tr>
        </tbody>
      </table>
    `
    insertHTML(table)
  }

  // Insert code block
  const insertCodeBlock = () => {
    const code = `
      <pre class="my-4 p-4 rounded-md bg-secondary text-secondary-foreground overflow-auto">
        <code class="text-sm">// Your code here</code>
      </pre>
    `
    insertHTML(code)
  }

  // Insert checkbox
  const insertCheckbox = () => {
    const checkbox = `
      <div class="flex items-center my-2">
        <input type="checkbox" class="mr-2 h-4 w-4 rounded border-gray-300">
        <span>New task</span>
      </div>
    `
    insertHTML(checkbox)
  }

  // Apply document template
  const applyTemplate = (templateName: string) => {
    let templateContent = ""

    switch (templateName) {
      case "product-spec":
        templateContent = `
          <h1 class="text-3xl font-bold">Product Specification</h1>
          <p class="text-gray-500 mt-2">Last updated: ${new Date().toLocaleDateString()}</p>
          
          <h2 class="text-2xl font-bold mt-6">1. Overview</h2>
          <p class="mt-2">Brief description of the product and its purpose.</p>
          
          <h2 class="text-2xl font-bold mt-6">2. Goals and Objectives</h2>
          <p class="mt-2">What problems does this product solve? What are the key objectives?</p>
          
          <h2 class="text-2xl font-bold mt-6">3. Features and Requirements</h2>
          <h3 class="text-xl font-semibold mt-4">3.1 Core Features</h3>
          <ul class="list-disc pl-6 mt-2">
            <li>Feature 1</li>
            <li>Feature 2</li>
            <li>Feature 3</li>
          </ul>
          
          <h3 class="text-xl font-semibold mt-4">3.2 Technical Requirements</h3>
          <p class="mt-2">Outline the technical specifications and requirements.</p>
          
          <h2 class="text-2xl font-bold mt-6">4. User Stories</h2>
          <p class="mt-2">Describe key user journeys and scenarios.</p>
          
          <h2 class="text-2xl font-bold mt-6">5. Design Specifications</h2>
          <p class="mt-2">Include UI/UX guidelines, wireframes, or mockups.</p>
          
          <h2 class="text-2xl font-bold mt-6">6. Timeline and Milestones</h2>
          <p class="mt-2">Outline the development schedule and key milestones.</p>
          
          <h2 class="text-2xl font-bold mt-6">7. Success Metrics</h2>
          <p class="mt-2">How will we measure the success of this product?</p>
        `
        break
      case "meeting-notes":
        templateContent = `
          <h1 class="text-3xl font-bold">Meeting Notes</h1>
          <p class="text-gray-500 mt-2">Date: ${new Date().toLocaleDateString()}</p>
          
          <h2 class="text-2xl font-bold mt-6">Attendees</h2>
          <ul class="list-disc pl-6 mt-2">
            <li>Person 1</li>
            <li>Person 2</li>
            <li>Person 3</li>
          </ul>
          
          <h2 class="text-2xl font-bold mt-6">Agenda</h2>
          <ol class="list-decimal pl-6 mt-2">
            <li>Topic 1</li>
            <li>Topic 2</li>
            <li>Topic 3</li>
          </ol>
          
          <h2 class="text-2xl font-bold mt-6">Discussion</h2>
          <p class="mt-2">Summary of key points discussed.</p>
          
          <h2 class="text-2xl font-bold mt-6">Action Items</h2>
          <div class="mt-2">
            <div class="flex items-center my-2">
              <input type="checkbox" class="mr-2 h-4 w-4 rounded border-gray-300">
              <span>Task 1 - Assigned to: Person 1, Due: TBD</span>
            </div>
            <div class="flex items-center my-2">
              <input type="checkbox" class="mr-2 h-4 w-4 rounded border-gray-300">
              <span>Task 2 - Assigned to: Person 2, Due: TBD</span>
            </div>
            <div class="flex items-center my-2">
              <input type="checkbox" class="mr-2 h-4 w-4 rounded border-gray-300">
              <span>Task 3 - Assigned to: Person 3, Due: TBD</span>
            </div>
          </div>
          
          <h2 class="text-2xl font-bold mt-6">Next Meeting</h2>
          <p class="mt-2">Date and time of the next meeting.</p>
        `
        break
      case "project-plan":
        templateContent = `
          <h1 class="text-3xl font-bold">Project Plan</h1>
          <p class="text-gray-500 mt-2">Created: ${new Date().toLocaleDateString()}</p>
          
          <h2 class="text-2xl font-bold mt-6">1. Project Overview</h2>
          <p class="mt-2">Brief description of the project, its goals, and expected outcomes.</p>
          
          <h2 class="text-2xl font-bold mt-6">2. Team Members</h2>
          <ul class="list-disc pl-6 mt-2">
            <li>Project Manager: [Name]</li>
            <li>Designer: [Name]</li>
            <li>Developer: [Name]</li>
            <li>QA Engineer: [Name]</li>
          </ul>
          
          <h2 class="text-2xl font-bold mt-6">3. Timeline</h2>
          <table class="border-collapse w-full my-4">
            <thead>
              <tr class="bg-secondary">
                <th class="border p-3 text-left">Phase</th>
                <th class="border p-3 text-left">Start Date</th>
                <th class="border p-3 text-left">End Date</th>
                <th class="border p-3 text-left">Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="border p-3">Planning</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">Not Started</td>
              </tr>
              <tr>
                <td class="border p-3">Design</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">Not Started</td>
              </tr>
              <tr>
                <td class="border p-3">Development</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">Not Started</td>
              </tr>
              <tr>
                <td class="border p-3">Testing</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">Not Started</td>
              </tr>
              <tr>
                <td class="border p-3">Deployment</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">TBD</td>
                <td class="border p-3">Not Started</td>
              </tr>
            </tbody>
          </table>
          
          <h2 class="text-2xl font-bold mt-6">4. Milestones</h2>
          <ul class="list-disc pl-6 mt-2">
            <li>Milestone 1: [Description] - [Date]</li>
            <li>Milestone 2: [Description] - [Date]</li>
            <li>Milestone 3: [Description] - [Date]</li>
          </ul>
          
          <h2 class="text-2xl font-bold mt-6">5. Resources</h2>
          <p class="mt-2">List of resources required for the project.</p>
          
          <h2 class="text-2xl font-bold mt-6">6. Risks and Mitigation</h2>
          <p class="mt-2">Identify potential risks and mitigation strategies.</p>
        `
        break
      default:
        templateContent = ""
    }

    if (editorRef.current && templateContent) {
      editorRef.current.innerHTML = templateContent
      setIsTemplateDialogOpen(false)
    }
  }

  return (
    <>
      {/* Document Header */}
      <header className="flex h-16 items-center justify-between border-b px-4 md:px-6">
        <div className="flex items-center gap-2 md:gap-4 overflow-hidden">
          <div className="flex items-center min-w-0">
            <Button variant="ghost" size="sm" className="gap-1">
              <FileText className="h-4 w-4 flex-shrink-0" />
              <input
                type="text"
                value={documentTitle}
                onChange={(e) => setDocumentTitle(e.target.value)}
                className="bg-transparent border-none outline-none focus:ring-0 p-0 text-sm font-medium truncate"
              />
            </Button>
          </div>
          <div className="hidden md:block h-4 w-px bg-border"></div>
          <div className="hidden md:flex items-center gap-1">
            <div className="flex -space-x-2">
              {collaborators
                .filter((c) => c.online)
                .map((user) => (
                  <TooltipProvider key={user.id}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Avatar className="h-6 w-6 border-2 border-background">
                          <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                          <AvatarFallback>{user.initials}</AvatarFallback>
                        </Avatar>
                      </TooltipTrigger>
                      <TooltipContent>{user.name}</TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                ))}
            </div>
            <span className="text-xs text-muted-foreground ml-2">
              {isSaving ? "Saving..." : `Saved ${formatLastSaved(lastSaved)}`}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1 sm:gap-2">
          {/* View Mode Switcher */}
          <div className="hidden sm:block">
            <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as ViewMode)} className="w-[250px]">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="edit" className="text-xs">
                  <PenLine className="h-3 w-3 mr-1" />
                  Edit
                </TabsTrigger>
                <TabsTrigger value="read" className="text-xs">
                  <Eye className="h-3 w-3 mr-1" />
                  Read
                </TabsTrigger>
                <TabsTrigger value="present" className="text-xs">
                  <Presentation className="h-3 w-3 mr-1" />
                  Present
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Mobile View Mode Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild className="sm:hidden">
              <Button variant="outline" size="sm" className="gap-1 h-8 px-2">
                {viewMode === "edit" ? (
                  <PenLine className="h-4 w-4" />
                ) : viewMode === "read" ? (
                  <Eye className="h-4 w-4" />
                ) : (
                  <Presentation className="h-4 w-4" />
                )}
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setViewMode("edit")}>
                <PenLine className="h-4 w-4 mr-2" />
                Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setViewMode("read")}>
                <Eye className="h-4 w-4 mr-2" />
                Read
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setViewMode("present")}>
                <Presentation className="h-4 w-4 mr-2" />
                Present
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            variant="outline"
            size="sm"
            className="gap-1 h-8 px-2 sm:px-3"
            onClick={saveDocument}
            disabled={isSaving}
          >
            <Save className="h-4 w-4" />
            <span className="hidden sm:inline">Save</span>
          </Button>

          <Dialog open={isVersionHistoryOpen} onOpenChange={setIsVersionHistoryOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1 h-8 px-2 sm:px-3 hidden sm:flex">
                <History className="h-4 w-4" />
                <span className="hidden sm:inline">History</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Version History</DialogTitle>
                <DialogDescription>View and restore previous versions of this document.</DialogDescription>
              </DialogHeader>
              <ScrollArea className="h-[300px] mt-4">
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => {
                    const date = new Date()
                    date.setHours(date.getHours() - i * 2)
                    return (
                      <div key={i} className="flex items-start gap-3 p-2 rounded-md hover:bg-secondary">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
                          <AvatarFallback>{i % 2 === 0 ? "JD" : "SL"}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-sm">{i % 2 === 0 ? "John Doe" : "Sarah Lee"}</span>
                            <span className="text-xs text-muted-foreground">
                              {date.toLocaleTimeString()} {date.toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {i === 0
                              ? "Current version"
                              : i === 1
                                ? "Added section on technical requirements"
                                : i === 2
                                  ? "Updated timeline and milestones"
                                  : i === 3
                                    ? "Added user stories section"
                                    : "Initial document creation"}
                          </p>
                        </div>
                        <Button variant="ghost" size="sm" className="h-7 px-2 text-xs">
                          Restore
                        </Button>
                      </div>
                    )
                  })}
                </div>
              </ScrollArea>
            </DialogContent>
          </Dialog>

          <Dialog open={isCollaborationDialogOpen} onOpenChange={setIsCollaborationDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1 h-8 px-2 sm:px-3">
                <Share2 className="h-4 w-4" />
                <span className="hidden sm:inline">Share</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Share Document</DialogTitle>
                <DialogDescription>Invite others to collaborate on this document.</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="share-email">Email address</Label>
                  <div className="flex gap-2">
                    <Input id="share-email" placeholder="colleague@example.com" />
                    <Button>Invite</Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>People with access</Label>
                  <div className="space-y-2">
                    {collaborators.map((user) => (
                      <div key={user.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                            <AvatarFallback>{user.initials}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium text-sm">{user.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {user.online ? (
                                <span className="flex items-center">
                                  <span className="h-1.5 w-1.5 rounded-full bg-green-500 mr-1"></span>
                                  Online
                                </span>
                              ) : (
                                "Offline"
                              )}
                            </div>
                          </div>
                        </div>
                        <Select defaultValue="edit">
                          <SelectTrigger className="w-[110px] h-8 text-xs">
                            <SelectValue placeholder="Permission" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="view">Can view</SelectItem>
                            <SelectItem value="comment">Can comment</SelectItem>
                            <SelectItem value="edit">Can edit</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="share-link">Share link</Label>
                  <div className="flex gap-2">
                    <Input id="share-link" value="https://workspacehub.com/docs/product-specs" readOnly />
                    <Button variant="outline">Copy</Button>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Button variant="outline" size="sm" className="gap-1 h-8 px-2 sm:px-3 hidden sm:flex">
            <Star className="h-4 w-4" />
            <span className="hidden sm:inline">Favorite</span>
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setIsCommentMode(!isCommentMode)}>
                <MessageSquare className="h-4 w-4 mr-2" />
                {isCommentMode ? "Exit Comment Mode" : "Comment Mode"}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setIsVersionHistoryOpen(true)}>
                <History className="h-4 w-4 mr-2" />
                Version History
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setIsTemplateDialogOpen(true)}>
                <FileTemplate className="h-4 w-4 mr-2" />
                Apply Template
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Bookmark className="h-4 w-4 mr-2" />
                Add to Bookmarks
              </DropdownMenuItem>
              <DropdownMenuItem>
                <FileText className="h-4 w-4 mr-2" />
                Export as PDF
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <ThemeToggle />
        </div>
      </header>

      {/* Template Dialog */}
      <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Apply Template</DialogTitle>
            <DialogDescription>Choose a template to apply to your document.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 py-4">
            <Button
              variant="outline"
              className="h-auto p-4 flex flex-col items-start justify-start text-left"
              onClick={() => applyTemplate("product-spec")}
            >
              <div className="font-medium mb-1">Product Specification</div>
              <p className="text-xs text-muted-foreground">
                A detailed template for product specifications with sections for features, requirements, and timelines.
              </p>
            </Button>
            <Button
              variant="outline"
              className="h-auto p-4 flex flex-col items-start justify-start text-left"
              onClick={() => applyTemplate("meeting-notes")}
            >
              <div className="font-medium mb-1">Meeting Notes</div>
              <p className="text-xs text-muted-foreground">
                A structured template for capturing meeting notes, attendees, action items, and decisions.
              </p>
            </Button>
            <Button
              variant="outline"
              className="h-auto p-4 flex flex-col items-start justify-start text-left"
              onClick={() => applyTemplate("project-plan")}
            >
              <div className="font-medium mb-1">Project Plan</div>
              <p className="text-xs text-muted-foreground">
                A comprehensive template for project planning with timelines, milestones, and resource allocation.
              </p>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-start justify-start text-left">
              <div className="font-medium mb-1">Blank Document</div>
              <p className="text-xs text-muted-foreground">Start with a clean slate for maximum flexibility.</p>
            </Button>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTemplateDialogOpen(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Formatting Toolbar - Only visible in edit mode */}
      {viewMode === "edit" && (
        <div className="border-b px-4 py-2 md:px-6 overflow-x-auto">
          <div className="flex items-center gap-1 flex-nowrap min-w-max">
            <div className="relative">
              <select
                className="h-9 w-[130px] appearance-none rounded-md border border-input bg-background px-3 py-1 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                onChange={(e) => formatBlock(e.target.value)}
              >
                <option value="p">Normal</option>
                <option value="h1">Heading 1</option>
                <option value="h2">Heading 2</option>
                <option value="h3">Heading 3</option>
                <option value="h4">Heading 4</option>
                <option value="h5">Heading 5</option>
                <option value="h6">Heading 6</option>
                <option value="blockquote">Quote</option>
                <option value="pre">Code</option>
              </select>
              <ChevronDown className="absolute right-2 top-2.5 h-4 w-4 opacity-50 pointer-events-none" />
            </div>

            <div className="h-6 w-px bg-border mx-1"></div>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("bold")}>
                    <Bold className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Bold</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("italic")}>
                    <Italic className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Italic</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("underline")}>
                    <Underline className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Underline</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("strikeThrough")}>
                    <Strikethrough className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Strikethrough</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <div className="h-6 w-px bg-border mx-1"></div>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("justifyLeft")}>
                    <AlignLeft className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Align Left</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("justifyCenter")}>
                    <AlignCenter className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Align Center</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("justifyRight")}>
                    <AlignRight className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Align Right</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("justifyFull")}>
                    <AlignJustify className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Justify</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <div className="h-6 w-px bg-border mx-1"></div>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-9 w-9"
                    onClick={() => execCommand("insertUnorderedList")}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Bullet List</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-9 w-9"
                    onClick={() => execCommand("insertOrderedList")}
                  >
                    <ListOrdered className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Numbered List</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={insertCheckbox}>
                    <CheckSquare className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Checkbox</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <div className="h-6 w-px bg-border mx-1"></div>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("undo")}>
                    <Undo className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Undo</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={() => execCommand("redo")}>
                    <Redo className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Redo</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <div className="h-6 w-px bg-border mx-1"></div>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={insertLink}>
                    <Link className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Insert Link</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={insertImage}>
                    <ImageIcon className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Insert Image</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={insertTable}>
                    <Table className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Insert Table</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-9 w-9" onClick={insertCodeBlock}>
                    <Code className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Insert Code Block</TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      )}

      {/* Document Content */}
      <div className={`flex-1 overflow-auto ${viewMode === "present" ? "bg-black" : ""}`}>
        <div
          className={`document-editor mx-auto ${
            viewMode === "present" ? "max-w-5xl p-16" : "p-8 md:p-12"
          } ${viewMode === "read" ? "prose prose-sm md:prose-base lg:prose-lg dark:prose-invert max-w-4xl" : ""}`}
        >
          <div
            className={`document-content space-y-6 min-h-[500px] ${
              viewMode === "present" ? "text-white" : ""
            } ${viewMode === "read" ? "" : "min-h-[500px]"}`}
            contentEditable={viewMode === "edit"}
            suppressContentEditableWarning
            spellCheck="true"
            id="document-content"
            ref={editorRef}
            onInput={() => {
              // Mark document as needing to be saved
              // In a real app, you might debounce this
              setIsSaving(false)
            }}
          >
            <h1 className="text-3xl font-bold">Product Specifications</h1>
            <p className="text-gray-500 mt-2">Last updated: April 3, 2025</p>

            <h2 className="text-2xl font-bold">Overview</h2>
            <p className="mt-2">
              This document outlines the specifications for our new product features and enhancements planned for Q2
              2025. The goal is to provide a comprehensive reference for all team members involved in the development,
              design, and marketing of these features.
            </p>

            <h2 className="text-2xl font-bold">Key Features</h2>
            <div className="mt-4 space-y-4">
              <div>
                <h3 className="text-xl font-semibold">1. User Authentication Enhancements</h3>
                <p className="mt-2">
                  We will be implementing OAuth 2.0 and adding support for social login options (Google, Apple, GitHub).
                  This will streamline the onboarding process and improve security.
                </p>
                <ul className="list-disc pl-6 mt-2">
                  <li>OAuth 2.0 implementation</li>
                  <li>Social login integration</li>
                  <li>Two-factor authentication</li>
                  <li>Password-less login options</li>
                </ul>
              </div>

              <div>
                <h3 className="text-xl font-semibold">2. Advanced Analytics Dashboard</h3>
                <p className="mt-2">
                  A new analytics dashboard will provide users with detailed insights into their usage patterns and
                  performance metrics.
                </p>
                <ul className="list-disc pl-6 mt-2">
                  <li>Customizable widgets</li>
                  <li>Real-time data visualization</li>
                  <li>Export capabilities (CSV, PDF)</li>
                  <li>Comparative analysis tools</li>
                </ul>
              </div>

              <div>
                <h3 className="text-xl font-semibold">3. Mobile Responsiveness</h3>
                <p className="mt-2">
                  All features will be fully responsive and optimized for mobile devices, ensuring a consistent
                  experience across all platforms.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Comment Mode Sidebar - Only visible when comment mode is active */}
      {isCommentMode && (
        <div className="border-l w-80 flex flex-col bg-background">
          <div className="flex items-center justify-between p-4 border-b">
            <h3 className="font-medium">Comments</h3>
            <Button variant="ghost" size="sm" onClick={() => setIsCommentMode(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-4 space-y-4">
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="John Doe" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 bg-secondary rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">John Doe</span>
                      <span className="text-xs text-muted-foreground">2h ago</span>
                    </div>
                    <p className="text-sm mt-1">
                      We should add more details about the mobile responsiveness feature. What specific platforms are we
                      targeting?
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2 pl-10">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Sarah Lee" />
                    <AvatarFallback>SL</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 bg-secondary rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">Sarah Lee</span>
                      <span className="text-xs text-muted-foreground">1h ago</span>
                    </div>
                    <p className="text-sm mt-1">
                      We're focusing on iOS, Android, and responsive web. I'll update the document with these details.
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Mike Thompson" />
                    <AvatarFallback>MT</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 bg-secondary rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">Mike Thompson</span>
                      <span className="text-xs text-muted-foreground">30m ago</span>
                    </div>
                    <p className="text-sm mt-1">
                      For the analytics dashboard, we should specify which data visualization libraries we'll be using.
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className="text-xs">
                        <Clock className="h-3 w-3 mr-1" />
                        Pending
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </ScrollArea>
          <div className="border-t p-4">
            <div className="flex items-start gap-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src="/placeholder.svg?height=32&width=32" alt="You" />
                <AvatarFallback>YO</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <Textarea placeholder="Add a comment..." className="min-h-[80px]" />
                <div className="flex justify-end mt-2">
                  <Button size="sm">Comment</Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
