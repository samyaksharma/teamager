"use client"

import * as React from "react"
import { ThemeProvider as NextThemesProvider } from "next-themes"
import type { ThemeProviderProps } from "next-themes/dist/types"

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  // Apply saved theme variant on mount
  React.useEffect(() => {
    const savedVariant = localStorage.getItem("theme-variant")
    if (savedVariant && savedVariant !== "default") {
      document.documentElement.classList.add(`theme-${savedVariant}`)
    }
  }, [])

  return <NextThemesProvider {...props}>{children}</NextThemesProvider>
}
