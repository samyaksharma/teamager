"use client"

import { useState, useEffect } from "react"
import { Moon, Sun, Palette } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from "@/components/ui/dropdown-menu"

export function ThemeToggle() {
  const { setTheme, theme, resolvedTheme } = useTheme()
  const [variant, setVariant] = useState("default")
  const [mounted, setMounted] = useState(false)

  // Only show the theme toggle on the client to avoid hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  // Apply theme and variant
  const applyTheme = (newTheme: string, newVariant: string) => {
    // Force the theme to be explicitly set rather than using system
    const actualTheme =
      newTheme === "system" ? (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light") : newTheme

    setTheme(actualTheme)

    // If switching to light theme, reset to default variant
    if (actualTheme === "light" && newVariant !== "default") {
      newVariant = "default"
    }

    setVariant(newVariant)
    localStorage.setItem("theme-variant", newVariant)

    // Remove previous variant classes
    document.documentElement.classList.remove(
      "theme-midnight",
      "theme-obsidian",
      "theme-nocturne",
      "theme-solstice",
      "theme-alabaster",
      "theme-morning-dew",
    )

    // Add new variant class if not default
    if (newVariant !== "default") {
      document.documentElement.classList.add(`theme-${newVariant}`)
    }
  }

  // Load saved variant on mount
  useEffect(() => {
    const savedVariant = localStorage.getItem("theme-variant") || "default"
    if (savedVariant !== "default") {
      setVariant(savedVariant)
      document.documentElement.classList.add(`theme-${savedVariant}`)
    }
  }, [mounted])

  if (!mounted) {
    return null
  }

  // Determine if we're in dark mode for variant selection
  const isDarkMode = resolvedTheme === "dark"

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
          <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          <span className="sr-only">Toggle theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => applyTheme("light", "default")}>
          <Sun className="mr-2 h-4 w-4" />
          <span>Light</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => applyTheme("dark", variant)}>
          <Moon className="mr-2 h-4 w-4" />
          <span>Dark</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuSub>
          <DropdownMenuSubTrigger>
            <Palette className="mr-2 h-4 w-4" />
            <span>Theme Variant</span>
          </DropdownMenuSubTrigger>
          <DropdownMenuSubContent>
            <DropdownMenuRadioGroup value={variant} onValueChange={(value) => applyTheme(theme || "light", value)}>
              <DropdownMenuRadioItem value="default">Default</DropdownMenuRadioItem>
              {isDarkMode ? (
                <>
                  <DropdownMenuRadioItem value="midnight">Midnight</DropdownMenuRadioItem>
                  <DropdownMenuRadioItem value="obsidian">Obsidian</DropdownMenuRadioItem>
                  <DropdownMenuRadioItem value="nocturne">Nocturne</DropdownMenuRadioItem>
                </>
              ) : (
                <>
                  <DropdownMenuRadioItem value="solstice">Solstice</DropdownMenuRadioItem>
                  <DropdownMenuRadioItem value="alabaster">Alabaster</DropdownMenuRadioItem>
                  <DropdownMenuRadioItem value="morning-dew">Morning Dew</DropdownMenuRadioItem>
                </>
              )}
            </DropdownMenuRadioGroup>
          </DropdownMenuSubContent>
        </DropdownMenuSub>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
