"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CheckCircle2 } from "lucide-react"

interface SignupData {
  organization: {
    name: string
    size: string
    industry: string
  }
  user: {
    name: string
    email: string
    password: string
  }
  preferences: {
    role: string
    department: string
    notifications: boolean
    termsAccepted: boolean
  }
}

interface SuccessStepProps {
  data: SignupData
}

export function SuccessStep({ data }: SuccessStepProps) {
  return (
    <div className="space-y-6 py-8">
      <div className="flex flex-col items-center justify-center text-center space-y-4">
        <div className="rounded-full bg-primary/10 p-3">
          <CheckCircle2 className="h-12 w-12 text-primary" />
        </div>
        <h1 className="text-2xl font-bold">Setup Complete!</h1>
        <p className="text-muted-foreground max-w-md">
          Your workspace <span className="font-medium">{data.organization.name}</span> has been created successfully.
          You can now access your dashboard and start collaborating with your team.
        </p>
      </div>

      <div className="space-y-4">
        <div className="rounded-lg border p-4">
          <h3 className="font-medium mb-2">Account Information</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="text-muted-foreground">Name:</div>
            <div>{data.user.name}</div>
            <div className="text-muted-foreground">Email:</div>
            <div>{data.user.email}</div>
            <div className="text-muted-foreground">Role:</div>
            <div>{data.preferences.role}</div>
            <div className="text-muted-foreground">Department:</div>
            <div>{data.preferences.department}</div>
          </div>
        </div>

        <div className="rounded-lg border p-4">
          <h3 className="font-medium mb-2">Organization Information</h3>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="text-muted-foreground">Organization:</div>
            <div>{data.organization.name}</div>
            <div className="text-muted-foreground">Size:</div>
            <div>{data.organization.size} employees</div>
            <div className="text-muted-foreground">Industry:</div>
            <div>{data.organization.industry}</div>
          </div>
        </div>
      </div>

      <div className="flex justify-center">
        <Link href="/dashboard">
          <Button size="lg">Go to Dashboard</Button>
        </Link>
      </div>
    </div>
  )
}
